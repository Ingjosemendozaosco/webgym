declare module 'jsqr';
